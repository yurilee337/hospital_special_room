-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: hospital_special_room
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `role` enum('admin','super_admin') NOT NULL DEFAULT 'admin',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'admin3','$2b$12$gteNteTNGy5cLBkL5I3SEO9hVsp90clmjfFcYoOLSCGkKCfaIgcve','ผู้ดูแลระบบ',NULL,'admin',1,1,'2026-11-12 14:19:47','2026-11-10 14:46:41','2026-11-12 14:19:47');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bed_name`
--

DROP TABLE IF EXISTS `bed_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bed_name` (
  `bed_name` varchar(255) DEFAULT NULL,
  `ward` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bed_name`
--

LOCK TABLES `bed_name` WRITE;
/*!40000 ALTER TABLE `bed_name` DISABLE KEYS */;
INSERT INTO `bed_name` VALUES ('VIP2','10'),('VIP3','10'),('VIP4','10'),('VIP5','10'),('VIP1','10'),('VIP101','11'),('VIP102','11'),('VIP103','11'),('VIP104','11'),('VIP105','11'),('SV301','12'),('SV302','12'),('SV303','12'),('SV304','12'),('SV305','12'),('SV401','13'),('SV402','13'),('SV403','13'),('SV404','13'),('SV405','13'),('พอ7-12','27'),('พอ7-13','27'),('พอ7-14','27'),('พอ7-2','27'),('พอ7-3','27'),('พอ7-4','27'),('พอ7-5','27'),('พอ7-6','27'),('พอ7-7','27'),('พอ7-8','27'),('พอ7-9','27'),('VIP_1','27'),('VIP_2','27'),('พอ7-1','27'),('พอ7-10','27'),('พอ7-11','27'),('พอ8-14','29'),('พอ8-2','29'),('พอ8-3','29'),('พอ8-4','29'),('พอ8-5','29'),('พอ8-6','29'),('พอ8-7','29'),('พอ8-8','29'),('พอ8-9','29'),('VIP8_1','29'),('VIP8_2','29'),('พอ8-1','29'),('พอ8-10','29'),('พอ8-11','29'),('พอ8-12','29'),('พอ8-13','29'),('พอ4-5','35'),('พอ4-6','35'),('พอ4-7','35'),('พอ4-8','35'),('พอ4-9','35'),('พอ4-01','35'),('พอ4-02','35'),('พอ4-03','35'),('พอ4-04','35'),('พอ4-1','35'),('พอ4-10','35'),('พอ4-11','35'),('พอ4-12','35'),('พอ4-2','35'),('พอ4-3','35'),('พอ4-4','35'),('พอ5-9','43'),('พอ5-1','43'),('พอ5-10','43'),('พอ5-11','43'),('พอ5-12','43'),('พอ5-2','43'),('พอ5-3','43'),('พอ5-4','43'),('พอ5-5','43'),('พอ5-6','43'),('พอ5-7','43'),('พอ5-8','43'),('พส3-2','46'),('พส3-3','46'),('พส3-4','46'),('พส3-5','46'),('พส3-6','46'),('พส3-7','46'),('พส3-8','46'),('พส3-9','46'),('พส3-1','46'),('พส3-10','46'),('พส3-11','46'),('พส3-12','46'),('พส3-13','46'),('พส3-14','46'),('พส3-15','46'),('พส4-3','47'),('พส4-4','47'),('พส4-5','47'),('พส4-6','47'),('พส4-7','47'),('พส4-8','47'),('พส4-9','47'),('พส4-1','47'),('พส4-10','47'),('พส4-11','47'),('พส4-12','47'),('พส4-13','47'),('พส4-14','47'),('พส4-15','47'),('พส4-2','47'),('พส5-4','48'),('พส5-5','48'),('พส5-6','48'),('พส5-7','48'),('พส5-8','48'),('พส5-9','48'),('พส5-1','48'),('พส5-10','48'),('พส5-11','48'),('พส5-12','48'),('พส5-13','48'),('พส5-14','48'),('พส5-15','48'),('พส5-2','48'),('พส5-3','48'),('พส6-5','49'),('พส6-6','49'),('พส6-7','49'),('พส6-8','49'),('พส6-9','49'),('พส6-1','49'),('พส6-10','49'),('พส6-11','49'),('พส6-12','49'),('พส6-13','49'),('พส6-14','49'),('พส6-15','49'),('พส6-2','49'),('พส6-3','49'),('พส6-4','49'),('SPP-5','51'),('SPP-6','51'),('SPP-7','51'),('SPP-8','51'),('SPP-9','51'),('SPP-1','51'),('SPP-10','51'),('SPP-2','51'),('SPP-3','51'),('SPP-4','51'),('พอ6-1','55'),('พอ6-10','55'),('พอ6-11','55'),('พอ6-12','55'),('พอ6-2','55'),('พอ6-3','55'),('พอ6-4','55'),('พอ6-5','55'),('พอ6-6','55'),('พอ6-7','55'),('พอ6-8','55'),('พอ6-9','55'),('พม2-04','69'),('พม2-05','69'),('พม2-06','69'),('พม2-07','69'),('พม2-08','69'),('พม2-09','69'),('พม2-10','69'),('พม2-11','69'),('พม2-12','69'),('พม2-01','69'),('พม2-02','69'),('พม2-03','69');
/*!40000 ALTER TABLE `bed_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `beds`
--

DROP TABLE IF EXISTS `beds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beds` (
  `bed_id` int(11) NOT NULL AUTO_INCREMENT,
  `ward_id` int(11) NOT NULL,
  `bed_name` varchar(30) NOT NULL,
  `room_type` varchar(100) DEFAULT NULL,
  `floor_number` varchar(20) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`bed_id`),
  UNIQUE KEY `uq_beds_ward_name` (`ward_id`,`bed_name`),
  KEY `idx_beds_ward` (`ward_id`),
  CONSTRAINT `fk_beds_wards` FOREIGN KEY (`ward_id`) REFERENCES `wards` (`ward_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `beds`
--

LOCK TABLES `beds` WRITE;
/*!40000 ALTER TABLE `beds` DISABLE KEYS */;
INSERT INTO `beds` VALUES (1,1,'VIP1',NULL,NULL,NULL,1,'2026-11-11 09:20:08','2026-11-11 10:42:27'),(2,1,'VIP2',NULL,NULL,NULL,1,'2026-11-11 09:20:08','2026-11-11 10:42:27'),(3,1,'VIP3',NULL,NULL,NULL,1,'2026-11-11 09:20:08','2026-11-11 10:42:27'),(4,1,'VIP4',NULL,NULL,NULL,1,'2026-11-11 09:20:08','2026-11-11 10:42:27'),(5,1,'VIP5',NULL,NULL,NULL,1,'2026-11-11 09:20:08','2026-11-11 10:42:27'),(6,2,'VIP101',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:18'),(7,2,'VIP102',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:22'),(8,2,'VIP103',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:27'),(9,2,'VIP104',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:30'),(10,2,'VIP105',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:33'),(11,3,'SV301',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:35'),(12,3,'SV302',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:37'),(13,3,'SV303',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:40'),(14,3,'SV304',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:44'),(15,3,'SV305',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:46'),(16,4,'SV401',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:47'),(17,4,'SV402',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:48'),(18,4,'SV403',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:49'),(19,4,'SV404',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:50'),(20,4,'SV405',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:51'),(21,5,'พอ7-12',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:52'),(22,5,'พอ7-13',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:54'),(23,5,'พอ7-14',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:55'),(24,5,'พอ7-2',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:57'),(25,5,'พอ7-3',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:58'),(26,5,'พอ7-4',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:02:59'),(27,5,'พอ7-5',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:01'),(28,5,'พอ7-6',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:02'),(29,5,'พอ7-7',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:03'),(30,5,'พอ7-8',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:05'),(31,5,'พอ7-9',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:06'),(32,5,'VIP_1',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:07'),(33,5,'VIP_2',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:08'),(34,5,'พอ7-1',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:09'),(35,5,'พอ7-10',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:10'),(36,5,'พอ7-11',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:11'),(37,6,'พอ8-14',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:12'),(38,6,'พอ8-2',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:14'),(39,6,'พอ8-3',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:16'),(40,6,'พอ8-4',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:17'),(41,6,'พอ8-5',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:19'),(42,6,'พอ8-6',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:22'),(43,6,'พอ8-7',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:23'),(44,6,'พอ8-8',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:24'),(45,6,'พอ8-9',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:25'),(46,6,'VIP8_1',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:26'),(47,6,'VIP8_2',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:26'),(48,6,'พอ8-1',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:27'),(49,6,'พอ8-10',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:28'),(50,6,'พอ8-11',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:29'),(51,6,'พอ8-12',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:31'),(52,6,'พอ8-13',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:32'),(53,7,'พอ4-5',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:33'),(54,7,'พอ4-6',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:34'),(55,7,'พอ4-7',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:35'),(56,7,'พอ4-8',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:36'),(57,7,'พอ4-9',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:37'),(58,7,'พอ4-01',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:38'),(59,7,'พอ4-02',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:39'),(60,7,'พอ4-03',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:42'),(61,7,'พอ4-04',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:43'),(62,7,'พอ4-1',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:44'),(63,7,'พอ4-10',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:45'),(64,7,'พอ4-11',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:46'),(65,7,'พอ4-12',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:48'),(66,7,'พอ4-2',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:48'),(67,7,'พอ4-3',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:50'),(68,7,'พอ4-4',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:51'),(69,8,'พอ5-9',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:53'),(70,8,'พอ5-1',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:54'),(71,8,'พอ5-10',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:56'),(72,8,'พอ5-11',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:57'),(73,8,'พอ5-12',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:58'),(74,8,'พอ5-2',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:59'),(75,8,'พอ5-3',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:03:59'),(76,8,'พอ5-4',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:01'),(77,8,'พอ5-5',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:02'),(78,8,'พอ5-6',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:04'),(79,8,'พอ5-7',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:05'),(80,8,'พอ5-8',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:06'),(81,9,'พส3-2',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:07'),(82,9,'พส3-3',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:09'),(83,9,'พส3-4',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:09'),(84,9,'พส3-5',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:10'),(85,9,'พส3-6',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:12'),(86,9,'พส3-7',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:13'),(87,9,'พส3-8',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:14'),(88,9,'พส3-9',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:15'),(89,9,'พส3-1',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:17'),(90,9,'พส3-10',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:19'),(91,9,'พส3-11',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:20'),(92,9,'พส3-12',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:21'),(93,9,'พส3-13',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:22'),(94,9,'พส3-14',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:24'),(95,9,'พส3-15',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:24'),(96,10,'พส4-3',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:25'),(97,10,'พส4-4',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:26'),(98,10,'พส4-5',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:27'),(99,10,'พส4-6',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:29'),(100,10,'พส4-7',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:31'),(101,10,'พส4-8',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:36'),(102,10,'พส4-9',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:37'),(103,10,'พส4-1',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:49'),(104,10,'พส4-10',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:51'),(105,10,'พส4-11',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:52'),(106,10,'พส4-12',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:53'),(107,10,'พส4-13',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:55'),(108,10,'พส4-14',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:56'),(109,10,'พส4-15',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:04:58'),(110,10,'พส4-2',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:00'),(111,11,'พส5-4',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:01'),(112,11,'พส5-5',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:02'),(113,11,'พส5-6',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:10'),(114,11,'พส5-7',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:07'),(115,11,'พส5-8',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:16'),(116,11,'พส5-9',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:18'),(117,11,'พส5-1',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:19'),(118,11,'พส5-10',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:21'),(119,11,'พส5-11',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:21'),(120,11,'พส5-12',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:23'),(121,11,'พส5-13',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:24'),(122,11,'พส5-14',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:25'),(123,11,'พส5-15',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:27'),(124,11,'พส5-2',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:28'),(125,11,'พส5-3',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:29'),(126,12,'พส6-5',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:30'),(127,12,'พส6-6',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:31'),(128,12,'พส6-7',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:32'),(129,12,'พส6-8',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:33'),(130,12,'พส6-9',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:34'),(131,12,'พส6-1',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:35'),(132,12,'พส6-10',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:36'),(133,12,'พส6-11',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:37'),(134,12,'พส6-12',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:39'),(135,12,'พส6-13',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:40'),(136,12,'พส6-14',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:41'),(137,12,'พส6-15',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:42'),(138,12,'พส6-2',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:44'),(139,12,'พส6-3',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:45'),(140,12,'พส6-4',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:46'),(141,13,'SPP-5',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:47'),(142,13,'SPP-6',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:48'),(143,13,'SPP-7',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:49'),(144,13,'SPP-8',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:50'),(145,13,'SPP-9',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:51'),(146,13,'SPP-1',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:52'),(147,13,'SPP-10',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:53'),(148,13,'SPP-2',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:54'),(149,13,'SPP-3',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:56'),(150,13,'SPP-4',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:05:58'),(151,14,'พอ6-1',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:00'),(152,14,'พอ6-10',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:01'),(153,14,'พอ6-11',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:02'),(154,14,'พอ6-12',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:03'),(155,14,'พอ6-2',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:05'),(156,14,'พอ6-3',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:07'),(157,14,'พอ6-4',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:16'),(158,14,'พอ6-5',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:24'),(159,14,'พอ6-6',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:26'),(160,14,'พอ6-7',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:27'),(161,14,'พอ6-8',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:28'),(162,14,'พอ6-9',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:30'),(163,15,'พม2-04',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:31'),(164,15,'พม2-05',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:32'),(165,15,'พม2-06',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:33'),(166,15,'พม2-07',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:35'),(167,15,'พม2-08',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:37'),(168,15,'พม2-09',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:38'),(169,15,'พม2-10',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:39'),(170,15,'พม2-11',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:41'),(171,15,'พม2-12',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:43'),(172,15,'พม2-01',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:44'),(173,15,'พม2-02',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:45'),(174,15,'พม2-03',NULL,NULL,NULL,1,'2026-11-11 10:42:27','2026-11-11 11:06:46');
/*!40000 ALTER TABLE `beds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluation_scores`
--

DROP TABLE IF EXISTS `evaluation_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `evaluation_scores` (
  `score_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `evaluation_id` bigint(20) NOT NULL,
  `topic_code` varchar(50) NOT NULL,
  `topic_name` varchar(150) NOT NULL,
  `score` tinyint(4) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`score_id`),
  UNIQUE KEY `unique_evaluation_topic` (`evaluation_id`,`topic_code`),
  KEY `idx_score_topic` (`topic_code`),
  KEY `idx_score_value` (`score`),
  CONSTRAINT `fk_scores_evaluations` FOREIGN KEY (`evaluation_id`) REFERENCES `evaluations` (`evaluation_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chk_score_range` CHECK (`score` between 1 and 5)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluation_scores`
--

LOCK TABLES `evaluation_scores` WRITE;
/*!40000 ALTER TABLE `evaluation_scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `evaluation_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluations`
--

DROP TABLE IF EXISTS `evaluations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `evaluations` (
  `evaluation_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `evaluation_code` varchar(30) NOT NULL,
  `bed_id` int(11) DEFAULT NULL,
  `ward_id` int(11) DEFAULT NULL,
  `qr_code_id` bigint(20) unsigned DEFAULT NULL,
  `respondent_type` enum('patient','relative','other') NOT NULL,
  `has_problem` tinyint(1) NOT NULL DEFAULT 0,
  `overall_score` decimal(3,2) NOT NULL,
  `suggestion` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`evaluation_id`),
  UNIQUE KEY `evaluation_code` (`evaluation_code`),
  KEY `idx_evaluation_date` (`created_at`),
  KEY `idx_evaluation_problem` (`has_problem`),
  KEY `idx_evaluation_qr` (`qr_code_id`),
  KEY `idx_evaluation_bed` (`bed_id`),
  KEY `idx_evaluation_ward` (`ward_id`),
  CONSTRAINT `fk_evaluations_beds` FOREIGN KEY (`bed_id`) REFERENCES `beds` (`bed_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_evaluations_survey_qr` FOREIGN KEY (`qr_code_id`) REFERENCES `survey_qr_codes` (`qr_code_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_evaluations_wards` FOREIGN KEY (`ward_id`) REFERENCES `wards` (`ward_id`) ON UPDATE CASCADE,
  CONSTRAINT `chk_overall_score` CHECK (`overall_score` >= 1 and `overall_score` <= 5)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluations`
--

LOCK TABLES `evaluations` WRITE;
/*!40000 ALTER TABLE `evaluations` DISABLE KEYS */;
/*!40000 ALTER TABLE `evaluations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `problem_categories`
--

DROP TABLE IF EXISTS `problem_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `problem_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_code` varchar(50) NOT NULL,
  `category_name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `category_code` (`category_code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problem_categories`
--

LOCK TABLES `problem_categories` WRITE;
/*!40000 ALTER TABLE `problem_categories` DISABLE KEYS */;
INSERT INTO `problem_categories` VALUES (1,'CLEANLINESS','ความสะอาด','ปัญหาความสะอาดภายในห้องพัก',1,'2026-11-10 14:07:07'),(2,'EQUIPMENT','อุปกรณ์ชำรุดหรือใช้งานไม่ได้','อุปกรณ์ภายในห้องชำรุดหรือไม่สามารถใช้งานได้',1,'2026-11-10 14:07:07'),(3,'INSUFFICIENT','อุปกรณ์หรือสิ่งของไม่เพียงพอ','สิ่งของหรืออุปกรณ์ภายในห้องมีไม่เพียงพอ',1,'2026-11-10 14:07:07'),(4,'ELECTRICAL','เครื่องปรับอากาศหรือระบบไฟฟ้า','ปัญหาเกี่ยวกับเครื่องปรับอากาศและระบบไฟฟ้า',1,'2026-11-10 14:07:07'),(5,'PLUMBING','ห้องน้ำหรือระบบประปา','ปัญหาเกี่ยวกับห้องน้ำและระบบน้ำ',1,'2026-11-10 14:07:07'),(6,'FACILITY','สิ่งอำนวยความสะดวก','ปัญหาเกี่ยวกับสิ่งอำนวยความสะดวก',1,'2026-11-10 14:07:07'),(7,'OTHER','อื่น ๆ','ปัญหาประเภทอื่นที่ไม่มีในรายการ',1,'2026-11-10 14:07:07');
/*!40000 ALTER TABLE `problem_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `problem_images`
--

DROP TABLE IF EXISTS `problem_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `problem_images` (
  `image_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `report_id` bigint(20) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `original_filename` varchar(255) NOT NULL,
  `stored_filename` varchar(255) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_size` int(10) unsigned NOT NULL,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`image_id`),
  UNIQUE KEY `stored_filename` (`stored_filename`),
  KEY `idx_image_report` (`report_id`),
  CONSTRAINT `fk_images_reports` FOREIGN KEY (`report_id`) REFERENCES `problem_reports` (`report_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problem_images`
--

LOCK TABLES `problem_images` WRITE;
/*!40000 ALTER TABLE `problem_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `problem_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `problem_report_categories`
--

DROP TABLE IF EXISTS `problem_report_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `problem_report_categories` (
  `report_category_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `report_id` bigint(20) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`report_category_id`),
  UNIQUE KEY `unique_report_category` (`report_id`,`category_id`),
  KEY `idx_report_category` (`category_id`),
  CONSTRAINT `fk_report_categories_categories` FOREIGN KEY (`category_id`) REFERENCES `problem_categories` (`category_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_report_categories_reports` FOREIGN KEY (`report_id`) REFERENCES `problem_reports` (`report_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problem_report_categories`
--

LOCK TABLES `problem_report_categories` WRITE;
/*!40000 ALTER TABLE `problem_report_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `problem_report_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `problem_reports`
--

DROP TABLE IF EXISTS `problem_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `problem_reports` (
  `report_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `evaluation_id` bigint(20) NOT NULL,
  `description` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`report_id`),
  UNIQUE KEY `evaluation_id` (`evaluation_id`),
  KEY `idx_report_date` (`created_at`),
  CONSTRAINT `fk_reports_evaluations` FOREIGN KEY (`evaluation_id`) REFERENCES `evaluations` (`evaluation_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problem_reports`
--

LOCK TABLES `problem_reports` WRITE;
/*!40000 ALTER TABLE `problem_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `problem_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_qr_codes`
--

DROP TABLE IF EXISTS `survey_qr_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `survey_qr_codes` (
  `qr_code_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `qr_token` varchar(128) NOT NULL,
  `building_name` varchar(150) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`qr_code_id`),
  UNIQUE KEY `qr_token` (`qr_token`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_qr_codes`
--

LOCK TABLES `survey_qr_codes` WRITE;
/*!40000 ALTER TABLE `survey_qr_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_qr_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_qr_wards`
--

DROP TABLE IF EXISTS `survey_qr_wards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `survey_qr_wards` (
  `qr_code_id` bigint(20) unsigned NOT NULL,
  `ward_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`qr_code_id`,`ward_id`),
  KEY `idx_survey_qr_wards_ward` (`ward_id`),
  CONSTRAINT `fk_survey_qr_wards_qr` FOREIGN KEY (`qr_code_id`) REFERENCES `survey_qr_codes` (`qr_code_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_survey_qr_wards_wards` FOREIGN KEY (`ward_id`) REFERENCES `wards` (`ward_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_qr_wards`
--

LOCK TABLES `survey_qr_wards` WRITE;
/*!40000 ALTER TABLE `survey_qr_wards` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_qr_wards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ward`
--

DROP TABLE IF EXISTS `ward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ward` (
  `ward` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `bedcount` varchar(255) DEFAULT NULL,
  `shortname` varchar(255) DEFAULT NULL,
  `shortname2` varchar(255) DEFAULT NULL,
  `is_active` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ward`
--

LOCK TABLES `ward` WRITE;
/*!40000 ALTER TABLE `ward` DISABLE KEYS */;
INSERT INTO `ward` VALUES ('10','ศัลยกรรมพิเศษ 1','5','ศพ 1',NULL,'N'),('11','ศัลยกรรมพิเศษ 2','5','ศพ 2',NULL,'N'),('12','ศัลยกรรมพิเศษ 3','5','ศพ 3',NULL,'N'),('13','ศัลยกรรมพิเศษ 4','5','ศพ 4',NULL,'N'),('27','พิเศษอาคารมะเร็ง ชั้น 7','16','พอ 7','ชั้น 7','Y'),('29','พิเศษอาคารมะเร็ง ชั้น 8','16','พอ 8','ชั้น 8','Y'),('35','พิเศษอายุรกรรม 4','16','พอ 4','ชั้น 4','Y'),('43','พิเศษอายุรกรรม 5','12','พอ 5','ชั้น 5','Y'),('46','พิเศษสงฆ์ฯ ชั้น 3','15','พส.ช3','ชั้น 3','Y'),('47','พิเศษสงฆ์ฯ ชั้น 4','15','พส.ช4','ชั้น 4','Y'),('48','พิเศษสงฆ์ฯ ชั้น 5','15','พส.ช5','ชั้น 5','Y'),('49','พิเศษสงฆ์ฯ ชั้น 6','15','พส.ช6','ชั้น 6','Y'),('51','สูติกรรมพิเศษ','10','สูติ.พ','ชั้น 2','Y'),('55','พิเศษอายุรกรรม 6','12','พอ 6','ชั้น 6','Y'),('69','พิเศษมหาวีโร 2','12','พ.ม2','พ.ม2','Y');
/*!40000 ALTER TABLE `ward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wards`
--

DROP TABLE IF EXISTS `wards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wards` (
  `ward_id` int(11) NOT NULL AUTO_INCREMENT,
  `ward_name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ward_code` varchar(30) DEFAULT NULL,
  `ward_shortname` varchar(60) DEFAULT NULL,
  `ward_shortname2` varchar(60) DEFAULT NULL,
  `bedcount` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ward_id`),
  UNIQUE KEY `uq_wards_ward_code` (`ward_code`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wards`
--

LOCK TABLES `wards` WRITE;
/*!40000 ALTER TABLE `wards` DISABLE KEYS */;
INSERT INTO `wards` VALUES (1,'ศัลยกรรมพิเศษ 1','ศพ 1',0,'2026-11-11 09:04:57','2026-11-11 10:42:27','10','ศพ 1',NULL,5),(2,'ศัลยกรรมพิเศษ 2','ศพ 2',0,'2026-11-11 09:04:57','2026-11-11 10:42:27','11','ศพ 2',NULL,5),(3,'ศัลยกรรมพิเศษ 3','ศพ 3',0,'2026-11-11 09:04:57','2026-11-11 10:42:27','12','ศพ 3',NULL,5),(4,'ศัลยกรรมพิเศษ 4','ศพ 4',0,'2026-11-11 09:04:57','2026-11-11 10:42:27','13','ศพ 4',NULL,5),(5,'พิเศษอาคารมะเร็ง ชั้น 7','พอ 7',1,'2026-11-11 09:04:57','2026-11-11 10:42:27','27','พอ 7','ชั้น 7',16),(6,'พิเศษอาคารมะเร็ง ชั้น 8','พอ 8',1,'2026-11-11 09:04:57','2026-11-11 10:42:27','29','พอ 8','ชั้น 8',16),(7,'พิเศษอายุรกรรม 4','พอ 4',1,'2026-11-11 09:04:57','2026-11-11 10:42:27','35','พอ 4','ชั้น 4',16),(8,'พิเศษอายุรกรรม 5','พอ 5',1,'2026-11-11 09:04:57','2026-11-11 10:42:27','43','พอ 5','ชั้น 5',12),(9,'พิเศษสงฆ์ฯ ชั้น 3','พส.ช3',1,'2026-11-11 09:04:57','2026-11-11 10:42:27','46','พส.ช3','ชั้น 3',15),(10,'พิเศษสงฆ์ฯ ชั้น 4','พส.ช4',1,'2026-11-11 09:04:57','2026-11-11 10:42:27','47','พส.ช4','ชั้น 4',15),(11,'พิเศษสงฆ์ฯ ชั้น 5','พส.ช5',1,'2026-11-11 09:04:57','2026-11-11 10:42:27','48','พส.ช5','ชั้น 5',15),(12,'พิเศษสงฆ์ฯ ชั้น 6','พส.ช6',1,'2026-11-11 09:04:57','2026-11-11 10:42:27','49','พส.ช6','ชั้น 6',15),(13,'สูติกรรมพิเศษ','สูติ.พ',1,'2026-11-11 09:04:57','2026-11-11 10:42:27','51','สูติ.พ','ชั้น 2',10),(14,'พิเศษอายุรกรรม 6','พอ 6',1,'2026-11-11 09:04:57','2026-11-11 10:42:27','55','พอ 6','ชั้น 6',12),(15,'พิเศษมหาวีโร 2','พ.ม2',1,'2026-11-11 10:42:27','2026-11-11 13:48:55','69','พ.ม2','พ.ม2',12);
/*!40000 ALTER TABLE `wards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'hospital_special_room'
--

--
-- Dumping routines for database 'hospital_special_room'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-12 14:23:50

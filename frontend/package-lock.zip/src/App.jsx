import { useEffect, useRef, useState } from "react";
import {
  Link,
  NavLink,
  Navigate,
  Route,
  Routes,
  useLocation,
  useNavigate,
  useParams,
} from "react-router-dom";
import {
  BarChart3,
  ClipboardList,
  Download,
  FileDown,
  LogOut,
  QrCode,
  Search,
  Star,
  TriangleAlert,
} from "lucide-react";
import { Bar, Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import Swal from "sweetalert2";
import { QRCodeSVG } from "qrcode.react";
import api, { getErrorMessage } from "./services/api";

let pdfJsPromise; //โหลดตัวอ่านไฟล์ PDF แบบ Lazy Load
function getPdfJs() {
  if (!pdfJsPromise) {
    pdfJsPromise = Promise.all([
      import("pdfjs-dist"),
      import("pdfjs-dist/build/pdf.worker.min.mjs?url"),
    ]).then(([pdfjsLib, workerUrl]) => {
      pdfjsLib.GlobalWorkerOptions.workerSrc = workerUrl.default;
      return pdfjsLib;
    });
  }
  return pdfJsPromise;
}

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Tooltip,
  Legend,
  Filler,
);

const topicLabels = {
  room_cleanliness: "ความสะอาดในห้องพัก",
  bathroom_cleanliness: "ความสะอาดของห้องน้ำ",
  overall_satisfaction: "ความพึงพอใจโดยรวมของห้องพิเศษ",
};
const respondentLabels = {
  patient: "ผู้ป่วย",
  relative: "ญาติ",
  other: "อื่นๆ",
};
const evaluationTopics = [
  "room_cleanliness",
  "bathroom_cleanliness",
  "overall_satisfaction",
];

const problemImageUrl = (imageId) =>
  `${api.defaults.baseURL.replace(/\/+$/, "")}/admin/problem-images/${imageId}`; //การตัดเครื่องหมาย / ส่วนเกินออกจาก Base URL

function Alert({ error }) {
  return error ? (
    <div className="alert alert-danger" role="alert">
      {error}
    </div>
  ) : null;
}

function EvaluationForm() {
  const location = useLocation();
  const qrToken = new URLSearchParams(location.search).get("qr") || ""; //ดึงรหัส QR Code จาก URL
  const [survey, setSurvey] = useState(null);
  const [loading, setLoading] = useState(Boolean(qrToken));
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({
    bed_id: "",
    respondent_type: "patient",
    has_problem: false,
    problem_description: "",
    suggestion: "",
    problem_category_ids: [],
    scores: evaluationTopics.reduce((a, key) => ({ ...a, [key]: 5 }), {}),
  });
  const [images, setImages] = useState([]);

  const [error, setError] = useState(
    qrToken ? "" : "กรุณาสแกน QR Code ประจำอาคารเพื่อเริ่มทำแบบประเมิน",
  );
  const [submitting, setSubmitting] = useState(false); //State สถานะกำลังส่งข้อมูล
  //ดักจับกรณีไม่มีรหัส QR Code
  useEffect(() => {
    if (!qrToken) {
      setSurvey(null);
      setLoading(false);
      setError("กรุณาสแกน QR Code ประจำอาคารเพื่อเริ่มทำแบบประเมิน");
      return;
    }
    setSurvey(null); //รีเซ็ตสถานะหน้าจอให้พร้อมโหลดข้อมูลใหม่
    setLoading(true);
    setError("");
    Promise.all([
      api.get(`/qr/${encodeURIComponent(qrToken)}`), //สั่งดึงข้อมูล 2 อย่างจาก Express Backend
      api.get("/problem-categories"),
    ])
      .then(([surveyResponse, categoryResponse]) => {
        setSurvey(surveyResponse.data);
        setCategories(categoryResponse.data);
        setForm((previous) => ({
          ...previous, //ตั้งค่าเตียงอัตโนมัติ
          bed_id: surveyResponse.data.locked_bed //ล็อกเตียงอัตโนมัติถ้ามีการกำหนดเตียงไว้แล้ว
            ? String(surveyResponse.data.locked_bed.bed_id)
            : "", //ถ้าไม่มีการล็อกเตียง ให้คงค่าเดิม
        }));
      })
      .catch((error) => setError(getErrorMessage(error)))
      .finally(() => setLoading(false));
  }, [qrToken]); //ให้รันโค้ดทั้งหมดนี้ใหม่เฉพาะตอนที่เปิดหน้าเว็บครั้งแรก หรือตอนที่ค่า qrToken ใน URL เปลี่ยนไปเท่านั้น

  const toggleCategory = (id) =>
    setForm((previous) => ({
      ...previous,
      problem_category_ids: previous.problem_category_ids.includes(id)
        ? previous.problem_category_ids.filter((item) => item !== id)
        : [...previous.problem_category_ids, id],
    }));

  async function submit(event) {
    event.preventDefault();
    setError("");
    setSubmitting(true);
    const data = new FormData();
    data.append("qr_token", qrToken);
    data.append("bed_id", form.bed_id);
    data.append("respondent_type", form.respondent_type);
    data.append("has_problem", form.has_problem ? "1" : "0");
    data.append("suggestion", form.suggestion);
    data.append("problem_description", form.problem_description);
    data.append(
      "problem_category_ids",
      JSON.stringify(form.problem_category_ids),
    );
    data.append(
      "scores",
      JSON.stringify(
        Object.entries(form.scores).map(([topic_code, score]) => ({
          topic_code,
          score: Number(score),
        })),
      ),
    );
    images.forEach((image) => data.append("images", image));
    try {
      await api.post("/evaluations", data);

      // 1. เพิ่มตัวมารับผลลัพธ์จาก Swal.fire และตั้งค่าป้องกันการกดปิดนอกป๊อปอัพ
      const result = await Swal.fire({
        title: "ขอบคุณสำหรับความคิดเห็น",
        text: "ส่งแบบประเมินเรียบร้อยแล้ว",
        icon: "success",
        confirmButtonText: "เรียบร้อย",
        allowOutsideClick: false,
        allowEscapeKey: false,
      });

      // 2. เมื่อผู้ใช้กดปุ่ม 'เรียบร้อย' ให้รีเฟรชหน้าเว็บเพื่อออกจากแบบสอบถามทันที
      if (result.isConfirmed) {
        window.location.href = window.location.pathname;
      }
    } catch (requestError) {
      setError(getErrorMessage(requestError));
      window.scrollTo({ top: 0, behavior: "smooth" });
    } finally {
      setSubmitting(false);
    }
  }
  return (
    <main className="survey-page">
      <div className="survey-topbar">
        <img
          className="hospital-logo"
          src="/hospital-logo.jpg"
          alt="โลโก้โรงพยาบาลร้อยเอ็ด"
          width="38"
          height="38"
        />
        <span>โรงพยาบาลร้อยเอ็ด</span>
        <Link to="/admin/login" className="admin-entry">
          ผู้ดูแลระบบ
        </Link>
      </div>
      <div className="survey-wrap">
        <div className="survey-heading">
          <div className="eyebrow">YOUR VOICE MATTERS</div>
          <h1>
            ประเมินความพึงพอใจ
            <br />
            <span>ห้องพิเศษ</span>
          </h1>
          <p>ความคิดเห็นของคุณช่วยให้เราพัฒนาการดูแลและบริการให้ดียิ่งขึ้น</p>
        </div>
        <form className="survey-card" onSubmit={submit}>
          <Alert error={error} />
          <section className="form-section">
            <div className="section-title">
              <span>01</span>
              <div>
                <h2>ข้อมูลการเข้าพัก</h2>
                <p>อาคารถูกกำหนดจาก QR Code ที่สแกน</p>
              </div>
            </div>
            <div className="row g-3">
              <div className="col-12">
                <label className="form-label">อาคาร</label>
                <div className="form-control bg-light" aria-live="polite">
                  {loading
                    ? "กำลังตรวจสอบ QR Code..."
                    : survey?.building_name || "ไม่พบอาคารจาก QR Code"}
                </div>
              </div>
              <div className="col-12">
                <label className="form-label">เลือกเตียง (ไม่บังคับ)</label>
                <select
                  className="form-select"
                  value={form.bed_id}
                  onChange={(event) =>
                    setForm({ ...form, bed_id: event.target.value })
                  }
                  disabled={!survey || loading || Boolean(survey?.locked_bed)}
                >
                  <option value="">ไม่ระบุเตียง</option>
                  {survey?.wards.map((ward) => (
                    <optgroup key={ward.ward_id} label={ward.ward_name}>
                      {ward.beds.map((bed) => (
                        <option key={bed.bed_id} value={bed.bed_id}>
                          {bed.bed_name}
                        </option>
                      ))}
                    </optgroup>
                  ))}
                </select>
                {survey?.locked_bed && (
                  <small className="text-muted d-block mt-2">
                    QR Code นี้กำหนดเตียง {survey.locked_bed.bed_name} ไว้แล้ว
                  </small>
                )}
                {survey && !survey.wards.some((ward) => ward.beds.length) && (
                  <small className="text-muted d-block mt-2">
                    อาคารนี้ยังไม่มีเตียงที่เปิดใช้งาน
                    สามารถส่งแบบประเมินโดยไม่ระบุเตียงได้
                  </small>
                )}
              </div>
              <div className="col-12">
                <label className="form-label">กำลังตอบแบบประเมินในฐานะ</label>
                <div className="choice-row">
                  {[
                    ["patient", "ผู้ป่วย"],
                    ["relative", "ญาติผู้ป่วย"],
                    ["other", "อื่นๆ"],
                  ].map(([value, label]) => (
                    <label
                      className={`choice-tile ${form.respondent_type === value ? "selected" : ""}`}
                      key={value}
                    >
                      <input
                        type="radio"
                        name="respondent"
                        value={value}
                        checked={form.respondent_type === value}
                        onChange={(event) =>
                          setForm({
                            ...form,
                            respondent_type: event.target.value,
                          })
                        }
                      />
                      {label}
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </section>
          <section className="form-section">
            <div className="section-title">
              <span>02</span>
              <div>
                <h2>ความพึงพอใจ</h2>
                <p>ให้คะแนนแต่ละหัวข้อ ตั้งแต่ 1 (ควรปรับปรุง) ถึง 5 (ดีมาก)</p>
              </div>
            </div>
            <div className="rating-list">
              {evaluationTopics.map((key) => (
                <div className="rating-row" key={key}>
                  <span>{topicLabels[key]}</span>
                  <div className="rating-options">
                    {[1, 2, 3, 4, 5].map((score) => (
                      <label
                        key={score}
                        className={
                          Number(form.scores[key]) === score ? "active" : ""
                        }
                      >
                        <input
                          type="radio"
                          name={key}
                          value={score}
                          checked={Number(form.scores[key]) === score}
                          onChange={() =>
                            setForm({
                              ...form,
                              scores: { ...form.scores, [key]: score },
                            })
                          }
                        />
                        <Star
                          size={15}
                          fill={
                            Number(form.scores[key]) >= score
                              ? "currentColor"
                              : "none"
                          }
                        />
                        {score}
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
          <section className="form-section last-section">
            <div className="section-title">
              <span>03</span>
              <div>
                <h2>ข้อเสนอแนะและแจ้งปัญหา</h2>
                <p>ไม่บังคับ — แจ้งสิ่งที่เราควรปรับปรุง</p>
              </div>
            </div>
            <label className="form-label">ข้อเสนอแนะ</label>
            <textarea
              className="form-control mb-3"
              rows="3"
              maxLength="5000"
              value={form.suggestion}
              onChange={(event) =>
                setForm({ ...form, suggestion: event.target.value })
              }
              placeholder="แจ้งสิ่งที่เราควรปรับปรุง..."
            />
            <label className="form-label">
              พบปัญหาหรือสิ่งที่ขาดเหลือหรือไม่
            </label>
            <div className="choice-row mb-3">
              {[
                [false, "ไม่มีปัญหา"],
                [true, "มีปัญหาหรือสิ่งที่ต้องการจะแจ้ง"],
              ].map(([value, label]) => (
                <label
                  className={`choice-tile ${form.has_problem === value ? "selected" : ""}`}
                  key={label}
                >
                  <input
                    type="radio"
                    name="has_problem"
                    checked={form.has_problem === value}
                    onChange={() => {
                      setForm((previous) => ({
                        ...previous,
                        has_problem: value,
                        ...(value
                          ? {}
                          : {
                              problem_description: "",
                              problem_category_ids: [],
                            }),
                      }));
                      if (!value) setImages([]);
                    }}
                  />
                  {label}
                </label>
              ))}
            </div>
            {form.has_problem && (
              <>
                <label className="form-label">
                  ประเภทปัญหา (เลือกได้มากกว่า 1 ข้อ)
                </label>
                <div className="category-list">
                  {categories.map((item) => (
                    <label
                      className="form-check category-chip"
                      key={item.category_id}
                    >
                      <input
                        className="form-check-input"
                        type="checkbox"
                        checked={form.problem_category_ids.includes(
                          item.category_id,
                        )}
                        onChange={() => toggleCategory(item.category_id)}
                      />
                      <span className="form-check-label">
                        {item.category_name}
                      </span>
                    </label>
                  ))}
                </div>
                <label className="form-label mt-3">รายละเอียดเพิ่มเติม</label>
                <textarea
                  className="form-control mb-3"
                  rows="3"
                  maxLength="5000"
                  value={form.problem_description}
                  onChange={(event) =>
                    setForm({
                      ...form,
                      problem_description: event.target.value,
                    })
                  }
                  placeholder="ระบุรายละเอียดปัญหา (ถ้ามี)"
                />
                <label className="form-label">
                  แนบรูปภาพ (JPG, PNG, WEBP ไม่เกิน 3 รูป รูปละ 5 MB)
                </label>
                <input
                  className="form-control"
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  multiple
                  onChange={(event) =>
                    setImages(Array.from(event.target.files || []).slice(0, 3))
                  }
                />
                {images.length > 0 && (
                  <small className="text-muted d-block mt-2">
                    เลือก {images.length} รูป
                  </small>
                )}
              </>
            )}
          </section>
          <button
            className="btn btn-primary submit-button"
            disabled={submitting || loading || !survey}
          >
            {submitting ? "กำลังส่ง..." : "ส่งแบบประเมิน"}
          </button>
          <div className="privacy-note">
            ข้อมูลของคุณจะถูกนำไปใช้เพื่อพัฒนาคุณภาพบริการเท่านั้น
          </div>
        </form>
      </div>
    </main>
  );
}
function Login() {
  const navigate = useNavigate();
  const [credentials, setCredentials] = useState({
    username: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      await api.post("/admin/login", credentials);
      navigate("/admin", { replace: true });
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="login-page">
      <Link to="/" className="back-link">
        ← กลับหน้าประเมิน
      </Link>
      <form className="login-card" onSubmit={submit}>
        <img
          className="hospital-logo"
          src="/hospital-logo.jpg"
          alt="โลโก้โรงพยาบาลร้อยเอ็ด"
          width="38"
          height="38"
        />
        <div className="eyebrow">ADMINISTRATOR</div>
        <h1>เข้าสู่ระบบ</h1>
        <p>ระบบจัดการประเมินห้องพิเศษ</p>
        <Alert error={error} />
        <label className="form-label">ชื่อผู้ใช้</label>
        <input
          className="form-control mb-3"
          autoComplete="username"
          value={credentials.username}
          onChange={(event) =>
            setCredentials({ ...credentials, username: event.target.value })
          }
          required
        />
        <label className="form-label">รหัสผ่าน</label>
        <input
          className="form-control mb-4"
          type="password"
          autoComplete="current-password"
          value={credentials.password}
          onChange={(event) =>
            setCredentials({ ...credentials, password: event.target.value })
          }
          required
        />
        <button className="btn btn-primary w-100" disabled={busy}>
          {busy ? "กำลังเข้าสู่ระบบ..." : "เข้าสู่ระบบ"}
        </button>
      </form>
    </main>
  );
}
function AdminLayout({ children }) {
  const navigate = useNavigate();
  const [admin, setAdmin] = useState(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    api
      .get("/admin/me")
      .then((response) => setAdmin(response.data.admin))
      .catch(() => navigate("/admin/login", { replace: true }))
      .finally(() => setReady(true));
  }, [navigate]);
  async function logout() {
    try {
      await api.post("/admin/logout");
      navigate("/admin/login", { replace: true });
    } catch (error) {
      Swal.fire("ออกจากระบบไม่สำเร็จ", getErrorMessage(error), "error");
    }
  }
  if (!ready || !admin)
    return <div className="loading-screen">กำลังตรวจสอบสิทธิ์...</div>;
  const nav = [
    ["/admin", BarChart3, "ภาพรวม"],
    ["/admin/evaluations", ClipboardList, "ผลการประเมิน"],
    ["/admin/reports", TriangleAlert, "รายการแจ้งปัญหา"],
    ["/admin/qr-codes", QrCode, "QR Code อาคาร/เตียง"],
  ];
  return (
    <div className="admin-shell">
      <aside className="sidebar">
        <Link to="/admin" className="sidebar-brand">
          <img
            className="hospital-logo"
            src="/hospital-logo.jpg"
            alt="โลโก้โรงพยาบาลร้อยเอ็ด"
            width="38"
            height="38"
          />
          <span>
            ห้องพิเศษ<small>ADMIN CONSOLE</small>
          </span>
        </Link>
        <div className="sidebar-label">เมนูหลัก</div>
        {nav.map(([to, Icon, label]) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/admin"}
            className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
          >
            <Icon size={18} />
            {label}
          </NavLink>
        ))}
        <div className="sidebar-bottom">
          <div className="admin-avatar">
            {admin.username.slice(0, 1).toUpperCase()}
          </div>
          <div className="admin-name">
            {admin.username}
            <small>ผู้ดูแลระบบ</small>
          </div>
          <button title="ออกจากระบบ" className="logout-btn" onClick={logout}>
            <LogOut size={18} />
          </button>
        </div>
      </aside>
      <main className="admin-main">{children}</main>
    </div>
  );
}

function PageHeader({ eyebrow, title, description, children }) {
  return (
    <div className="page-header">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {children}
    </div>
  );
}

function QrManagement() {
  const [wards, setWards] = useState([]);
  const [codes, setCodes] = useState([]);
  const [problemCategories, setProblemCategories] = useState([]); // เก็บหมวดหมู่ปัญหาสำหรับพิมพ์ลง A4
  // 1. State form เริ่มต้น (แยก include_unassigned ออกจาก selected_bed_ids)
  const [form, setForm] = useState({
    qr_code_id: null,
    building_name: "",
    ward_ids: [],
    selected_ward_id: "",
    selected_bed_ids: [],
    include_unassigned: false,
    is_active: 1,
  });
  const [previewCodes, setPreviewCodes] = useState([]);
  const [printJob, setPrintJob] = useState(null);
  const [surveyPrintJob, setSurveyPrintJob] = useState(null); // State สำหรับหน้าพิมพ์แบบประเมิน A4
  const [viewQrByWard, setViewQrByWard] = useState({});
  const [selectedQrIdsByWard, setSelectedQrIdsByWard] = useState({});
  const [openQrPickerByWard, setOpenQrPickerByWard] = useState({});
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [editingWard, setEditingWard] = useState(null);
  const qrPreviewRef = useRef(null);

  async function load() {
    try {
      const [wardResponse, codeResponse, categoryResponse] = await Promise.all([
        api.get("/admin/wards"),
        api.get("/admin/qr-codes"),
        api.get("/problem-categories"),
      ]);
      setWards(wardResponse.data);
      setCodes(codeResponse.data);
      setProblemCategories(categoryResponse.data);
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    }
  }
  const selectedWardId =
    form.selected_ward_id ||
    (form.ward_ids.length === 1 ? String(form.ward_ids[0]) : "");
  const selectedWard = wards.find(
    (ward) => String(ward.ward_id) === String(selectedWardId),
  );
  const selectedWardCodes = codes.filter((code) =>
    code.ward_ids.some((id) => String(id) === String(selectedWardId)),
  );
  const assignedBedIds = new Set(
    selectedWardCodes
      .filter(
        (code) =>
          String(code.qr_code_id) !== String(form.qr_code_id) &&
          code.bed_id !== null,
      )
      .map((code) => String(code.bed_id)),
  );
  const availableBeds = (selectedWard?.beds || []).filter(
    (bed) => Number(bed.is_active) && !assignedBedIds.has(String(bed.bed_id)),
  );

  useEffect(() => {
    load();
  }, []);
  useEffect(() => {
    if (previewCodes.length)
      qrPreviewRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
  }, [previewCodes]);
  function chooseWard(wardId) {
    setPreviewCodes([]);
    setNotice("");
    setForm((previous) => ({
      ...previous,
      selected_ward_id: wardId,
      selected_bed_ids: [],
      include_unassigned: false,
    }));
  }

  function toggleBed(bedId, checked) {
    const id = String(bedId);
    setForm((previous) => ({
      ...previous,
      selected_bed_ids: checked
        ? [...new Set([...previous.selected_bed_ids.map(String), id])]
        : previous.selected_bed_ids.filter(
            (selectedId) => String(selectedId) !== id,
          ),
    }));
    setPreviewCodes([]);
  }
  function toggleAllAvailableBeds() {
    const availableIds = availableBeds.map((bed) => String(bed.bed_id));
    const selectedIds = form.selected_bed_ids.map(String);
    const allSelected =
      availableIds.length > 0 &&
      availableIds.every((id) => selectedIds.includes(id));

    setForm((previous) => ({
      ...previous,
      // เปลี่ยนเฉพาะเตียงที่ยังไม่มี QR โดยไม่แตะตัวเลือก "ไม่ผูกเตียง"
      selected_bed_ids: allSelected
        ? previous.selected_bed_ids.filter(
            (id) => !availableIds.includes(String(id)),
          )
        : [
            ...new Set([
              ...previous.selected_bed_ids.map(String),
              ...availableIds,
            ]),
          ],
    }));
    setPreviewCodes([]);
  }

  async function save(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const wardIds = selectedWardId ? [Number(selectedWardId)] : [];
      if (!wardIds.length) throw new Error("กรุณาเลือก Ward");
      const availableBedIdSet = new Set(
        availableBeds.map((bed) => String(bed.bed_id)),
      );
      const bedIds = form.selected_bed_ids
        .map(Number)
        .filter((id) => availableBedIdSet.has(String(id)));
      if (!bedIds.length && !form.include_unassigned) {
        throw new Error(
          "กรุณาเลือกเตียงอย่างน้อย 1 เตียง หรือเลือกไม่ผูกเตียง",
        );
      }
      const payload = {
        building_name: form.building_name,
        ward_ids: wardIds,
        bed_ids: bedIds,
        include_unassigned: Boolean(form.include_unassigned),
        is_active: form.is_active,
      };
      const response = await api.post("/admin/qr-codes", payload);
      const createdCodes = response.data.qr_codes || [response.data];
      setPreviewCodes(createdCodes);
      setNotice(`สร้าง QR Code แล้ว ${createdCodes.length} รายการ`);
      setForm({
        qr_code_id: null,
        building_name: "",
        ward_ids: [],
        selected_ward_id: "",
        selected_bed_ids: [],
        include_unassigned: false,
        is_active: 1,
      });
      await load();
    } catch (requestError) {
      setError(
        requestError.response
          ? getErrorMessage(requestError)
          : requestError.message,
      );
    } finally {
      setBusy(false);
    }
  }
  async function saveWardStatus() {
    if (!editingWard) return;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await api.put(`/admin/wards/${editingWard.ward_id}/status`, {
        is_active: editingWard.is_active,
      });
      setEditingWard(null);
      setNotice("บันทึกสถานะ Ward แล้ว");
      await load();
    } catch (requestError) {
      setError(getErrorMessage(requestError));
    } finally {
      setBusy(false);
    }
  }

  async function printCodes(printCodes) {
    setBusy(true);
    setError("");
    try {
      const pdfjsLib = await getPdfJs();
      const pdf = await pdfjsLib.getDocument("/templates/qr-ward-template.pdf")
        .promise;
      const page = await pdf.getPage(1);
      const viewport = page.getViewport({ scale: 4 });
      const canvas = document.createElement("canvas");
      canvas.width = Math.ceil(viewport.width);
      canvas.height = Math.ceil(viewport.height);
      const context = canvas.getContext("2d");
      if (!context) throw new Error("ไม่สามารถเตรียมภาพเทมเพลตสำหรับพิมพ์ได้");
      await page.render({ canvasContext: context, viewport }).promise;
      setPrintJob({
        templateImage: canvas.toDataURL("image/png"),
        codes: printCodes,
      });
    } catch (printError) {
      setError(printError.message || "ไม่สามารถสร้างเอกสารสำหรับพิมพ์ได้");
    } finally {
      setBusy(false);
    }
  }
  // ฟังก์ชันเปิดหน้าตัวอย่างก่อนพิมพ์แบบประเมิน A4 ตาม Ward และเตียงที่เลือก
  function printSurveyForms(targetCodes) {
    setSurveyPrintJob({ codes: targetCodes });
  }

  async function deleteCode(code) {
    const confirmation = await Swal.fire({
      title: "ยืนยันการลบ QR Code?",
      text: `QR Code สำหรับ ${code.building_name} จะถูกลบ และ Ward จะสามารถกำหนด QR Code ใหม่ได้`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "ลบ QR Code",
      cancelButtonText: "ยกเลิก",
      confirmButtonColor: "#dc3545",
    });
    if (!confirmation.isConfirmed) return;

    setBusy(true);
    setError("");
    setNotice("");
    try {
      await api.delete(`/admin/qr-codes/${code.qr_code_id}`);
      setPreviewCodes((previous) =>
        previous.filter((preview) => preview.qr_code_id !== code.qr_code_id),
      );
      await load();
      await Swal.fire({
        title: "ลบสำเร็จ",
        text: `ลบ QR Code สำหรับ ${code.building_name} เรียบร้อยแล้ว`,
        icon: "success",
        confirmButtonText: "ตกลง",
      });
    } catch (requestError) {
      setError(getErrorMessage(requestError));
      const errorMessage = getErrorMessage(requestError);
      setError(errorMessage);
      await Swal.fire({
        title: "ลบไม่สำเร็จ",
        text: errorMessage,
        icon: "error",
        confirmButtonText: "ตกลง",
      });
    } finally {
      setBusy(false);
    }
  }
  async function deleteSelectedCodes(targetCodes, wardId) {
    if (!targetCodes.length) return;
    if (targetCodes.length === 1) {
      return deleteCode(targetCodes[0]);
    }

    const confirmation = await Swal.fire({
      title: `ยืนยันการลบ QR Code ทั้ง ${targetCodes.length} รายการ?`,
      text: "QR Code ที่เลือกทั้งหมดจะถูกลบ และเตียงเหล่านี้จะสามารถสร้าง QR Code ใหม่ได้",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: `ลบทั้งหมด (${targetCodes.length})`,
      cancelButtonText: "ยกเลิก",
      confirmButtonColor: "#dc3545",
    });
    if (!confirmation.isConfirmed) return;

    setBusy(true);
    setError("");
    setNotice("");
    try {
      await Promise.all(
        targetCodes.map((code) =>
          api.delete(`/admin/qr-codes/${code.qr_code_id}`),
        ),
      );
      const deletedIds = new Set(
        targetCodes.map((code) => String(code.qr_code_id)),
      );
      setPreviewCodes((previous) =>
        previous.filter(
          (preview) => !deletedIds.has(String(preview.qr_code_id)),
        ),
      );
      if (wardId) {
        setSelectedQrIdsByWard((previous) => ({ ...previous, [wardId]: [] }));
        setOpenQrPickerByWard((previous) => ({ ...previous, [wardId]: false }));
      }
      await load();
      await Swal.fire({
        title: "ลบสำเร็จ",
        text: `ลบ QR Code เรียบร้อยแล้ว ${targetCodes.length} รายการ`,
        icon: "success",
        confirmButtonText: "ตกลง",
      });
    } catch (requestError) {
      const errorMessage = getErrorMessage(requestError);
      setError(errorMessage);
      await Swal.fire({
        title: "ลบไม่สำเร็จ",
        text: errorMessage,
        icon: "error",
        confirmButtonText: "ตกลง",
      });
    } finally {
      setBusy(false);
    }
  }
  const wardGroups = wards.map((ward) => {
    const wardCodes = codes.filter((code) =>
      code.ward_ids.some((id) => String(id) === String(ward.ward_id)),
    );
    const selectedCodeId = viewQrByWard[ward.ward_id];
    const selectedCode =
      wardCodes.find(
        (code) => String(code.qr_code_id) === String(selectedCodeId),
      ) || wardCodes[0];
    return { ward, codes: wardCodes, selectedCode };
  });

  const unassignedWards = wards.filter(
    (ward) =>
      Number(ward.is_active) &&
      !codes.some((code) =>
        code.ward_ids.some((id) => String(id) === String(ward.ward_id)),
      ),
  );

  const completedWardIds = new Set(
    wards
      .filter((ward) => {
        const wardCodes = codes.filter((code) =>
          code.ward_ids.some((id) => String(id) === String(ward.ward_id)),
        );
        const activeBedIds = ward.beds
          .filter((bed) => Number(bed.is_active))
          .map((bed) => String(bed.bed_id));
        return (
          activeBedIds.length > 0 &&
          activeBedIds.every((bedId) =>
            wardCodes.some((code) => String(code.bed_id) === bedId),
          )
        );
      })
      .map((ward) => String(ward.ward_id)),
  );

  function getSelectedCodesForWard(wardId, wardCodes, fallbackCode) {
    const selectedIds = selectedQrIdsByWard[wardId];
    if (selectedIds === undefined) return fallbackCode ? [fallbackCode] : [];
    return wardCodes.filter((code) =>
      selectedIds.includes(String(code.qr_code_id)),
    );
  }

  function toggleWardQrCode(wardId, codeId, checked, fallbackCode) {
    const id = String(codeId);
    setSelectedQrIdsByWard((previous) => {
      const current =
        previous[wardId] ??
        (fallbackCode ? [String(fallbackCode.qr_code_id)] : []);
      return {
        ...previous,
        [wardId]: checked
          ? [...new Set([...current, id])]
          : current.filter((selectedId) => selectedId !== id),
      };
    });
    setPreviewCodes([]);
    setNotice("");
  }

  function toggleAllWardQrCodes(wardId, wardCodes, fallbackCode) {
    const current = getSelectedCodesForWard(wardId, wardCodes, fallbackCode);
    const allSelected =
      wardCodes.length > 0 && current.length === wardCodes.length;
    setSelectedQrIdsByWard((previous) => ({
      ...previous,
      [wardId]: allSelected
        ? []
        : wardCodes.map((code) => String(code.qr_code_id)),
    }));
    setPreviewCodes([]);
    setNotice("");
  }

  function downloadQrCode(event, buildingName) {
    const svg = event.currentTarget
      .closest(".qr-preview-card")
      ?.querySelector("svg");
    if (!svg) {
      setError("ไม่พบ QR Code สำหรับดาวน์โหลด");
      return;
    }
    const fileName = (buildingName || "qr-code")
      .trim()
      .replace(/[<>:"/\\|?*\u0000-\u001F]/g, "-")
      .replace(/\s+/g, "-");
    const blob = new Blob([new XMLSerializer().serializeToString(svg)], {
      type: "image/svg+xml;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${fileName}.svg`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  return (
    <>
      <PageHeader
        eyebrow="WARD & BED QR CODES"
        title="จัดการ QR Code อาคารและเตียง"
        description="เลือก Ward แล้วกำหนด QR สำหรับทุกเตียง เตียงเดียว หรือให้ผู้ประเมินเลือกเตียงเอง"
      />
      <Alert error={error} />
      {unassignedWards.length > 0 && (
        <div className="alert alert-warning">
          Ward ที่ยังไม่ได้กำหนด QR Code:{" "}
          {unassignedWards
            .map((ward) => `${ward.ward_code} ${ward.ward_name}`)
            .join("、")}
        </div>
      )}
      <section className="content-card mb-3">
        <h2>เพิ่ม QR Code</h2>
        <form className="mt-3" onSubmit={save}>
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label">Ward</label>
              <select
                className="form-select"
                value={selectedWardId}
                onChange={(event) => chooseWard(event.target.value)}
              >
                <option value="">เลือก Ward</option>
                {wards.map((ward) => (
                  <option
                    key={ward.ward_id}
                    value={ward.ward_id}
                    disabled={
                      !Number(ward.is_active) ||
                      completedWardIds.has(String(ward.ward_id))
                    }
                  >
                    {ward.ward_code} · {ward.ward_name}
                    {completedWardIds.has(String(ward.ward_id))
                      ? " · สร้าง QR ครบแล้ว"
                      : Number(ward.is_active)
                        ? ""
                        : " · ปิดใช้งาน"}
                  </option>
                ))}
              </select>
            </div>
            <div className="col-12">
              <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-2">
                <label className="form-label mb-0">
                  เลือกเตียง (เลือกได้หลายเตียง)
                </label>
                <button
                  type="button"
                  className="btn btn-sm btn-outline-primary"
                  disabled={!selectedWard || !availableBeds.length}
                  onClick={toggleAllAvailableBeds}
                >
                  {availableBeds.length > 0 &&
                  availableBeds.every((bed) =>
                    form.selected_bed_ids
                      .map(String)
                      .includes(String(bed.bed_id)),
                  )
                    ? "ยกเลิกเลือกทั้งหมด"
                    : "เลือกทั้งหมด"}
                </button>
              </div>
              <label className="form-check border rounded p-2 ps-5 mb-2">
                <input
                  className="form-check-input"
                  type="checkbox"
                  checked={Boolean(form.include_unassigned)}
                  disabled={!selectedWard}
                  onChange={(event) => {
                    setForm((previous) => ({
                      ...previous,
                      include_unassigned: event.target.checked,
                    }));
                    setPreviewCodes([]);
                  }}
                />
                <span className="form-check-label">
                  ไม่ผูกเตียง · ให้ผู้ประเมินเลือกเอง
                </span>
              </label>

              <div className="row g-2">
                {selectedWard?.beds
                  .filter((bed) => Number(bed.is_active))
                  .map((bed) => {
                    const alreadyHasQr = assignedBedIds.has(String(bed.bed_id));
                    const checked = form.selected_bed_ids
                      .map(String)
                      .includes(String(bed.bed_id));
                    return (
                      <div className="col-sm-6 col-lg-4" key={bed.bed_id}>
                        <label
                          className={`form-check border rounded p-2 ps-5 h-100 ${alreadyHasQr ? "bg-light text-muted" : ""}`}
                        >
                          <input
                            className="form-check-input"
                            type="checkbox"
                            checked={alreadyHasQr ? false : checked}
                            disabled={alreadyHasQr || !selectedWard}
                            onChange={(event) =>
                              toggleBed(bed.bed_id, event.target.checked)
                            }
                          />
                          <span className="form-check-label">
                            {bed.bed_name}
                            {alreadyHasQr && (
                              <span className="badge bg-secondary ms-2">
                                มี QR แล้ว
                              </span>
                            )}
                          </span>
                        </label>
                      </div>
                    );
                  })}
                {selectedWard &&
                  !selectedWard.beds.some((bed) => Number(bed.is_active)) && (
                    <div className="col-12 text-muted">
                      Ward นี้ยังไม่มีเตียงที่เปิดใช้งาน
                    </div>
                  )}
              </div>
              <small className="text-muted d-block mt-2">
                เลือกเตียงได้หลายรายการพร้อมกัน และเลือก “ไม่ผูกเตียง”
                ควบคู่กันได้
                {` · เตียงที่มี QR แล้ว ${assignedBedIds.size} เตียงจะถูกล็อกไม่ให้เลือกซ้ำ`}
              </small>
            </div>
            <div className="col-md-6 d-flex align-items-end">
              <label className="form-check mb-2">
                <input
                  className="form-check-input"
                  type="checkbox"
                  checked={Boolean(form.is_active)}
                  onChange={(event) =>
                    setForm((previous) => ({
                      ...previous,
                      is_active: event.target.checked ? 1 : 0,
                    }))
                  }
                />
                <span className="form-check-label">เปิดใช้งาน QR Code</span>
              </label>
            </div>
            {selectedWard && (
              <div className="col-12 text-muted">
                {selectedWard.active_bed_count} เตียงที่เปิดใช้งานใน Ward นี้
              </div>
            )}
          </div>
          <div className="d-flex gap-2 mt-3">
            <button
              className="btn btn-primary"
              disabled={busy || !selectedWardId}
            >
              {busy ? "กำลังดำเนินการ..." : "สร้างและแสดง QR Code"}
            </button>
          </div>
        </form>
      </section>
      {notice && (
        <div className="alert alert-success mt-3" role="status">
          {notice}
        </div>
      )}
      {previewCodes.map((code, index) => {
        const surveyUrl = `${window.location.origin}/?qr=${encodeURIComponent(code.qr_token)}`;
        return (
          <section
            ref={index === 0 ? qrPreviewRef : undefined}
            key={code.qr_code_id}
            className="content-card qr-preview-card my-3 d-flex align-items-center gap-4 flex-wrap"
          >
            <QRCodeSVG value={surveyUrl} size={160} />
            <div>
              <h2>QR Code สำหรับ {code.building_name}</h2>
              <p className="mb-2">
                {code.bed_name || "ไม่ผูกเตียง · ผู้ประเมินเลือกเตียงเอง"}
              </p>
              <p className="mb-2">
                สแกน QR Code หรือเปิดลิงก์ด้านล่างเพื่อตรวจสอบได้
              </p>
              <a href={surveyUrl} target="_blank" rel="noreferrer">
                {surveyUrl}
              </a>
              <div className="mt-3 d-flex gap-2 flex-wrap">
                <button
                  type="button"
                  className="btn btn-outline-primary d-inline-flex align-items-center gap-2"
                  onClick={(event) => downloadQrCode(event, code.building_name)}
                >
                  <Download size={16} />
                  ดาวน์โหลด QR Code
                </button>
                <button
                  type="button"
                  className="btn btn-primary"
                  disabled={busy}
                  onClick={() => printCodes([code])}
                >
                  พิมพ์ QR Code
                </button>
                <button
                  type="button"
                  className="btn btn-outline-success"
                  disabled={busy}
                  onClick={() => printSurveyForms([code])}
                >
                  พิมพ์แบบประเมิน (A4)
                </button>
              </div>
            </div>
          </section>
        );
      })}
      <section className="content-card">
        <h2>QR Code แยกตาม Ward</h2>
        <div className="row g-3 mt-1">
          {wardGroups.map(({ ward, codes: wardCodes, selectedCode }) => (
            <div className="col-xl-6" key={ward.ward_id}>
              <div className="border rounded p-3 h-100">
                <div className="d-flex align-items-center justify-content-between gap-2">
                  <div>
                    <b>
                      {ward.ward_code} · {ward.ward_name}
                    </b>
                    <span
                      className={`status ms-2 ${Number(ward.is_active) ? "status-ok" : "status-muted"}`}
                    >
                      {Number(ward.is_active) ? "เปิดใช้งาน" : "ปิดใช้งาน"}
                    </span>
                  </div>
                  {editingWard?.ward_id === ward.ward_id ? (
                    <div className="d-flex align-items-center gap-2">
                      <select
                        className="form-select form-select-sm"
                        aria-label="สถานะ Ward"
                        value={editingWard.is_active}
                        onChange={(event) =>
                          setEditingWard({
                            ...editingWard,
                            is_active: Number(event.target.value),
                          })
                        }
                      >
                        <option value={1}>เปิดใช้งาน</option>
                        <option value={0}>ปิดใช้งาน</option>
                      </select>
                      <button
                        type="button"
                        className="btn btn-sm btn-primary"
                        disabled={busy}
                        onClick={saveWardStatus}
                      >
                        บันทึก
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-secondary"
                        disabled={busy}
                        onClick={() => setEditingWard(null)}
                      >
                        ยกเลิก
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      className="btn btn-sm btn-outline-primary"
                      disabled={busy}
                      onClick={() =>
                        setEditingWard({
                          ward_id: ward.ward_id,
                          is_active: Number(ward.is_active),
                        })
                      }
                    >
                      แก้ไข
                    </button>
                  )}
                </div>
                <div className="mt-2">
                  <label className="form-label">เลือก QR Code / เตียง</label>
                  {(() => {
                    const selectedCodes = getSelectedCodesForWard(
                      ward.ward_id,
                      wardCodes,
                      selectedCode,
                    );
                    const selectedIds = selectedCodes.map((code) =>
                      String(code.qr_code_id),
                    );
                    const allSelected =
                      wardCodes.length > 0 &&
                      selectedCodes.length === wardCodes.length;
                    const selectedLabel = selectedCodes
                      .map(
                        (code) =>
                          code.bed_name || "ไม่ผูกเตียง · เลือกเตียงเอง",
                      )
                      .join(", ");

                    return (
                      <>
                        <div className="position-relative">
                          <button
                            type="button"
                            className="form-select text-start"
                            disabled={!wardCodes.length}
                            aria-expanded={Boolean(
                              openQrPickerByWard[ward.ward_id],
                            )}
                            onClick={() =>
                              setOpenQrPickerByWard((previous) => ({
                                ...previous,
                                [ward.ward_id]: !previous[ward.ward_id],
                              }))
                            }
                            style={{
                              minHeight: 48,
                              whiteSpace: "normal",
                              overflowWrap: "anywhere",
                            }}
                          >
                            {selectedCodes.length
                              ? `${selectedCodes.length} รายการ: ${selectedLabel}`
                              : "เลือก QR Code / เตียง"}
                          </button>

                          {openQrPickerByWard[ward.ward_id] &&
                            wardCodes.length > 0 && (
                              <div
                                className="dropdown-menu show w-100 p-3 shadow-sm"
                                style={{
                                  maxHeight: 280,
                                  overflowY: "auto",
                                  zIndex: 20,
                                }}
                              >
                                {/* แถวเลือกทั้งหมด */}
                                <label
                                  className="d-flex align-items-center gap-2 pb-2 mb-2 border-bottom"
                                  style={{ cursor: "pointer" }}
                                >
                                  <input
                                    className="form-check-input m-0 flex-shrink-0"
                                    type="checkbox"
                                    checked={allSelected}
                                    onChange={() =>
                                      toggleAllWardQrCodes(
                                        ward.ward_id,
                                        wardCodes,
                                        selectedCode,
                                      )
                                    }
                                  />
                                  <span className="fw-semibold">
                                    All · เลือกทั้งหมด ({wardCodes.length})
                                  </span>
                                </label>

                                {/* รายการเตียงเรียง 3 คอลัมน์ */}
                                <div
                                  style={{
                                    display: "grid",
                                    gridTemplateColumns:
                                      "repeat(3, minmax(0, 1fr))",
                                    gap: "8px 12px",
                                  }}
                                >
                                  {wardCodes.map((code) => {
                                    const codeId = String(code.qr_code_id);
                                    return (
                                      <label
                                        key={code.qr_code_id}
                                        className="d-flex align-items-center gap-2 py-1 px-1 rounded"
                                        style={{ cursor: "pointer" }}
                                      >
                                        <input
                                          className="form-check-input m-0 flex-shrink-0"
                                          type="checkbox"
                                          checked={selectedIds.includes(codeId)}
                                          onChange={(event) =>
                                            toggleWardQrCode(
                                              ward.ward_id,
                                              code.qr_code_id,
                                              event.target.checked,
                                              selectedCode,
                                            )
                                          }
                                        />
                                        <span className="text-truncate">
                                          {code.bed_name ||
                                            "ไม่ผูกเตียง · เลือกเตียงเอง"}
                                        </span>
                                      </label>
                                    );
                                  })}
                                </div>
                              </div>
                            )}
                        </div>

                        {wardCodes.length > 0 && (
                          <div className="d-flex gap-2 flex-wrap align-items-center mt-3">
                            <span className="status status-muted">
                              เลือกแล้ว {selectedCodes.length} /{" "}
                              {wardCodes.length} รายการ
                            </span>
                            <button
                              type="button"
                              className="btn btn-sm btn-success"
                              disabled={busy || !selectedCodes.length}
                              onClick={() => printSurveyForms(selectedCodes)}
                            >
                              พิมพ์แบบประเมิน
                              {selectedCodes.length
                                ? ` (${selectedCodes.length})`
                                : ""}
                            </button>
                            <button
                              type="button"
                              className="btn btn-sm btn-outline-secondary"
                              disabled={busy || !selectedCodes.length}
                              onClick={() => printCodes(selectedCodes)}
                            >
                              พิมพ์ QR Code
                              {selectedCodes.length
                                ? ` (${selectedCodes.length})`
                                : ""}
                            </button>
                            {selectedCodes.length === 1 && (
                              <span
                                className={`status ${Number(selectedCodes[0].is_active) ? "status-ok" : "status-muted"}`}
                              >
                                {Number(selectedCodes[0].is_active)
                                  ? "ใช้งาน"
                                  : "ปิดใช้งาน"}
                              </span>
                            )}
                            <button
                              type="button"
                              className="btn btn-sm btn-outline-danger"
                              disabled={busy || !selectedCodes.length}
                              onClick={() =>
                                deleteSelectedCodes(selectedCodes, ward.ward_id)
                              }
                            >
                              ลบ
                              {selectedCodes.length > 1
                                ? ` (${selectedCodes.length})`
                                : ""}
                            </button>
                          </div>
                        )}
                      </>
                    );
                  })()}
                </div>
              </div>
            </div>
          ))}
          {!wards.length && (
            <div className="col-12">
              <div className="empty-state">ยังไม่มี Ward ให้นำเข้าและกำหนด</div>
            </div>
          )}
        </div>
        {previewCodes.length > 1 && (
          <button
            type="button"
            className="btn btn-primary mt-3"
            disabled={busy}
            onClick={() => printCodes(previewCodes)}
          >
            พิมพ์ QR Code ทั้ง {previewCodes.length} รายการ
          </button>
        )}
      </section>
      {/* หน้าต่างตัวอย่างก่อนพิมพ์ QR Code เดิม */}
      {printJob && (
        <div
          className="qr-print-preview"
          role="dialog"
          aria-modal="true"
          aria-label="ตัวอย่างก่อนพิมพ์"
        >
          <div className="qr-print-actions">
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => window.print()}
            >
              สั่งพิมพ์
            </button>
            <button
              type="button"
              className="btn btn-outline-secondary"
              onClick={() => setPrintJob(null)}
            >
              ปิดตัวอย่าง
            </button>
          </div>
          <div className="qr-print-pages">
            {printJob.codes.map((code) => {
              const surveyUrl = `${window.location.origin}/?qr=${encodeURIComponent(code.qr_token)}`;
              const wardTitle =
                code.wards?.length === 1
                  ? `${code.wards[0].ward_code || ""} ${code.wards[0].ward_name}`.trim()
                  : code.building_name;
              return (
                <div className="qr-print-page" key={code.qr_code_id}>
                  <img
                    className="qr-print-template"
                    src={printJob.templateImage}
                    alt=""
                  />
                  <div className="qr-print-title">{wardTitle}</div>
                  <div className="qr-print-bed-label">
                    {code.bed_name || "สแกนตรงนี้"}
                  </div>
                  <div className="qr-print-code">
                    <QRCodeSVG
                      value={surveyUrl}
                      size={420}
                      level="H"
                      includeMargin
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
      {/* หน้าต่างตัวอย่างก่อนพิมพ์แบบประเมินรูปแบบกระดาษ A4 */}
      {surveyPrintJob && (
        <div
          className="qr-print-preview"
          role="dialog"
          aria-modal="true"
          aria-label="ตัวอย่างแบบประเมิน A4"
        >
          <div className="qr-print-actions">
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => window.print()}
            >
              สั่งพิมพ์แบบประเมิน (A4)
            </button>
            <button
              type="button"
              className="btn btn-outline-secondary"
              onClick={() => setSurveyPrintJob(null)}
            >
              ปิดตัวอย่าง
            </button>
          </div>
          <div className="qr-print-pages">
            {surveyPrintJob.codes.map((code) => {
              const wardTitle =
                code.wards?.length === 1
                  ? `${code.wards[0].ward_code || ""} ${code.wards[0].ward_name}`.trim()
                  : code.building_name;
              return (
                <div className="a4-survey-page" key={code.qr_code_id}>
                  {/* ส่วนหัวเอกสาร */}
                  <div className="a4-header">
                    <img
                      src="/hospital-logo.jpg"
                      alt="โลโก้โรงพยาบาลร้อยเอ็ด"
                      className="a4-logo"
                    />
                    <div>
                      <h1 className="a4-title">
                        แบบประเมินความพึงพอใจห้องพิเศษ โรงพยาบาลร้อยเอ็ด
                      </h1>
                      <p className="a4-subtitle">
                        ความคิดเห็นของท่านช่วยให้เราพัฒนาการดูแลและบริการให้ดียิ่งขึ้น
                      </p>
                    </div>
                  </div>
                  {/* ส่วนที่ 1: ข้อมูลการเข้าพัก */}
                  <div className="a4-section">
                    <div className="a4-section-title">
                      ส่วนที่ 1 : ข้อมูลการเข้าพัก
                    </div>
                    <div className="a4-info-grid">
                      <div>
                        <strong>หอผู้ป่วย / Ward :</strong> {wardTitle}
                      </div>
                      <div>
                        <strong>เตียง :</strong>{" "}
                        {code.bed_name ||
                          "............................................"}
                      </div>
                      <div>
                        <strong>วันที่ประเมิน :</strong> ........ / ........ /
                        ............
                      </div>
                    </div>
                    <div className="a4-checkbox-row mt-2">
                      <strong>ผู้ตอบแบบประเมิน :</strong>
                      <span>
                        <span className="a4-box" /> ผู้ป่วย
                      </span>
                      <span>
                        <span className="a4-box" /> ญาติผู้ป่วย
                      </span>
                      <span>
                        <span className="a4-box" /> อื่นๆ (ระบุ
                        ....................................)
                      </span>
                    </div>
                  </div>
                  {/* ส่วนที่ 2: คะแนนความพึงพอใจ (ช่องว่างเปล่า 1-5 ไม่เลือกค่าเริ่มต้น) */}
                  <div className="a4-section">
                    <div className="a4-section-title">
                      ส่วนที่ 2 : ความพึงพอใจต่อบริการ (กรุณาทำเครื่องหมาย ✓
                      ลงในช่องคะแนน)
                    </div>
                    <table className="a4-rating-table">
                      <thead>
                        <tr>
                          <th style={{ width: "50%", textAlign: "left" }}>
                            หัวข้อการประเมิน
                          </th>
                          <th>
                            5<br />
                            <small>ดีมาก</small>
                          </th>
                          <th>
                            4<br />
                            <small>ดี</small>
                          </th>
                          <th>
                            3<br />
                            <small>ปานกลาง</small>
                          </th>
                          <th>
                            2<br />
                            <small>พอใช้</small>
                          </th>
                          <th>
                            1<br />
                            <small>ควรปรับปรุง</small>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {evaluationTopics.map((key, idx) => (
                          <tr key={key}>
                            <td>
                              {idx + 1}. {topicLabels[key]}
                            </td>
                            {[5, 4, 3, 2, 1].map((score) => (
                              <td key={score} className="a4-score-cell">
                                <span className="a4-star-box">☆ {score}</span>
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {/* ส่วนที่ 3: การแจ้งปัญหา (แสดงหมวดหมู่ย่อยทั้งหมดให้เลือกติ๊กได้ทันที) */}
                  <div className="a4-section">
                    <div className="a4-section-title">
                      ส่วนที่ 3 : การแจ้งปัญหาหรือสิ่งที่ขาดเหลือ
                    </div>
                    <div className="a4-checkbox-row mb-2">
                      <strong>พบปัญหาหรือไม่ :</strong>
                      <span>
                        <span className="a4-box" /> ไม่มีปัญหา
                      </span>
                      <span>
                        <span className="a4-box" />{" "}
                        มีปัญหาหรือสิ่งที่ต้องการแจ้ง
                        (กรุณาเลือกประเภทปัญหาด้านล่าง)
                      </span>
                    </div>
                    <div className="a4-category-box">
                      <div className="mb-1">
                        <strong>ประเภทปัญหา (เลือกได้มากกว่า 1 ข้อ) :</strong>
                      </div>
                      <div className="a4-category-grid">
                        {[...problemCategories]
                          .sort((a, b) => {
                            const aIsOther = a.category_name.includes("อื่น");
                            const bIsOther = b.category_name.includes("อื่น");
                            return Number(aIsOther) - Number(bIsOther);
                          })
                          .map((cat) => (
                            <div
                              className="a4-category-item"
                              key={cat.category_id}
                            >
                              <span className="a4-box" /> {cat.category_name}
                            </div>
                          ))}
                      </div>
                    </div>
                    <div className="mt-2">
                      <strong>รายละเอียดปัญหาเพิ่มเติม :</strong>
                      <div className="a4-write-line" />
                      <div className="a4-write-line" />
                    </div>
                  </div>

                  {/* ส่วนที่ 4: ข้อเสนอแนะ */}
                  <div className="a4-section">
                    <div className="a4-section-title">
                      ส่วนที่ 4 : ข้อเสนอแนะเพิ่มเติม
                    </div>
                    <div className="a4-write-line" />
                    <div className="a4-write-line" />
                    <div className="a4-write-line" />
                  </div>

                  <div className="a4-footer">
                    ขอขอบคุณที่ร่วมแสดงความคิดเห็น —
                    ข้อมูลของท่านจะถูกนำไปใช้เพื่อพัฒนาคุณภาพบริการของโรงพยาบาลร้อยเอ็ดเท่านั้น
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </>
  );
}
function Dashboard() {
  const [data, setData] = useState(null); //เก็บข้อมูลสถิติและรายงานทั้งหมดที่ดึงมาจาก API
  const [error, setError] = useState("");
  const [months, setMonths] = useState(12);
  const [buildingFilter, setBuildingFilter] = useState("");
  const [selectedBuilding, setSelectedBuilding] = useState("");
  //ดึงข้อมูลสถิติแดชบอร์ดจากเซิร์ฟเวอร์โดยอัตโนมัติ
  useEffect(() => {
    setError("");
    api
      .get("/admin/dashboard", {
        params: { months, building: selectedBuilding || buildingFilter },
      }) //ส่งคำร้องขอข้อมูลสถิติ
      .then((response) => setData(response.data))
      .catch((err) => setError(getErrorMessage(err)));
  }, [months, buildingFilter, selectedBuilding]);
  const chartMonths = data
    ? Array.from({ length: months }, (_, index) => {
        const date = new Date();
        date.setDate(1);
        date.setMonth(date.getMonth() - months + index + 1);
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
      })
    : [];
  const buildingNames = data
    ? data.buildings.map((item) => item.building_name)
    : [];
  const visibleBuildings = buildingNames.filter(
    (name) => !buildingFilter || name === buildingFilter,
  );
  const colors = [
    "#3578e5",
    "#e3a32f",
    "#37a27a",
    "#8a66c7",
    "#df6f6f",
    "#39a1b5",
    "#d47aa8",
    "#78899f",
    "#e67e22",
    "#2ecc71",
    "#1abc9c",
    "#c0392b",
    "#5c6bc0",
    "#8d6e63",
    "#afb42b",
  ];
  const chartData =
    data &&
    (selectedBuilding
      ? {
          labels: chartMonths,
          datasets: [
            ...new Set(data.room_monthly.map((item) => item.room_name)),
          ].map((room, index) => ({
            label: room,
            data: chartMonths.map((month) => {
              const item = data.room_monthly.find(
                (row) => row.month === month && row.room_name === room,
              );
              return item ? Number(item.average_score) : null;
            }),
            borderColor: colors[index % colors.length],
            backgroundColor: colors[index % colors.length],
            tension: 0.3, //ความโค้งของเส้นกราฟ
            spanGaps: false,
          })),
        }
      : {
          labels: chartMonths,
          datasets: visibleBuildings.map((building, index) => ({
            label: building,
            data: chartMonths.map((month) => {
              const item = data.building_monthly.find(
                (row) => row.month === month && row.building_name === building,
              );
              return item ? Number(item.average_score) : null;
            }),
            backgroundColor: colors[index % colors.length],
            borderRadius: 4, //ความโค้งของมุมแท่งกราฟ
          })),
        });
  const chartOptions = {
    responsive: true, //ปรับขนาดอัตโนมัติตามขนาดหน้าจอ
    maintainAspectRatio: false, //ปิดการล็อกสัดส่วนความกว้างต่อความสูงแบบตายตัว
    interaction: { mode: "nearest", intersect: true },
    plugins: { legend: { position: "bottom" } },
    scales: { y: { min: 0, max: 5, ticks: { stepSize: 1 } } },
  };
  return (
    <>
      <PageHeader
        eyebrow="OVERVIEW"
        title="ภาพรวมระบบ"
        description="สรุปผลการประเมินห้องพิเศษของโรงพยาบาล"
      />
      <Alert error={error} />
      {data && (
        <>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-icon blue">
                <ClipboardList size={20} />
              </div>
              <div>
                <span>แบบประเมินทั้งหมด</span>
                <strong>
                  {Number(data.evaluation_count).toLocaleString()}
                </strong>
                <small>รายการ</small>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon gold">
                <Star size={20} />
              </div>
              <div>
                <span>คะแนนเฉลี่ย</span>
                <strong>
                  {Number(data.average_score).toFixed(2)}
                  <i> / 5</i>
                </strong>
                <small>จากทุกหัวข้อ</small>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon red">
                <TriangleAlert size={20} />
              </div>
              <div>
                <span>รายการแจ้งปัญหา</span>
                <strong>
                  {Number(data.problem_count || 0).toLocaleString()}
                </strong>
                <small>รายการ</small>
              </div>
            </div>
          </div>
          <section className="content-card dashboard-chart-card">
            <div className="dashboard-chart-heading">
              <div className="card-heading">
                <div>
                  <h2>
                    {selectedBuilding
                      ? `ผลประเมินรายห้อง · ${selectedBuilding}`
                      : "คะแนนเฉลี่ยรายเดือนแยกตามอาคาร"}
                  </h2>
                  <p>
                    {selectedBuilding
                      ? "คลิกปุ่มกลับเพื่อดูภาพรวมอาคาร"
                      : "คลิกแท่งกราฟของอาคารเพื่อดูผลประเมินรายห้อง"}
                  </p>
                </div>
              </div>
              <div className="dashboard-filters">
                {!selectedBuilding && (
                  <label>
                    อาคาร
                    <select
                      className="form-select"
                      value={buildingFilter}
                      onChange={(event) =>
                        setBuildingFilter(event.target.value)
                      }
                    >
                      <option value="">ทุกอาคาร</option>
                      {buildingNames.map((building) => (
                        <option key={building} value={building}>
                          {building}
                        </option>
                      ))}
                    </select>
                  </label>
                )}
                <label>
                  ช่วงเวลา
                  <select
                    className="form-select"
                    value={months}
                    onChange={(event) => setMonths(Number(event.target.value))}
                  >
                    <option value={3}>3 เดือน</option>
                    <option value={6}>6 เดือน</option>
                    <option value={12}>12 เดือน</option>
                  </select>
                </label>
                {selectedBuilding && (
                  <button
                    className="btn btn-outline-primary"
                    onClick={() => setSelectedBuilding("")}
                  >
                    กลับสู่อาคาร
                  </button>
                )}
              </div>
            </div>
            {chartData && (
              <div className="dashboard-chart">
                {selectedBuilding ? (
                  <Line data={chartData} options={chartOptions} />
                ) : (
                  <Bar
                    data={chartData}
                    options={{
                      ...chartOptions,
                      onClick: (_, elements) => {
                        if (elements.length)
                          setSelectedBuilding(
                            visibleBuildings[elements[0].datasetIndex],
                          );
                      },
                    }}
                  />
                )}
                {!chartData.datasets.some((dataset) =>
                  dataset.data.some((value) => value !== null),
                ) && (
                  <div className="empty-state">
                    ยังไม่มีข้อมูลการประเมินในช่วงเวลานี้
                  </div>
                )}
              </div>
            )}
          </section>
          <section className="content-card top-rooms">
            <div className="card-heading">
              <div>
                <h2>เตียงที่มีการประเมินสูง</h2>
                <p>เรียงตามจำนวนแบบประเมิน</p>
              </div>
            </div>
            {data.top_rooms.length ? (
              <div className="table-responsive">
                <table className="table align-middle">
                  <thead>
                    <tr>
                      <th>เตียง</th>
                      <th>จำนวน</th>
                      <th>คะแนนเฉลี่ย</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.top_rooms.map((item, index) => (
                      <tr key={`${item.ward_name}-${item.bed_name}`}>
                        <td>
                          <span className="rank">{index + 1}</span>
                          <b>
                            {item.ward_name} · {item.bed_name}
                          </b>
                        </td>
                        <td>{item.evaluation_count}</td>
                        <td>
                          <span className="score-pill">
                            <Star size={13} fill="currentColor" />
                            {Number(item.average_score).toFixed(2)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="empty-state">ยังไม่มีข้อมูลการประเมิน</div>
            )}
          </section>
        </>
      )}
    </>
  );
}
function Evaluations() {
  const [data, setData] = useState({ data: [], pagination: {} });
  const [wards, setWards] = useState([]);
  const [filters, setFilters] = useState({
    q: "",
    ward_id: "",
    from: "",
    to: "",
    has_problem: "",
  });
  const [error, setError] = useState("");
  const [page, setPage] = useState(1);
  const load = (requestedPage = page) =>
    api
      .get("/admin/evaluations", {
        params: { ...filters, page: requestedPage },
      })
      .then((response) => setData(response.data))
      .catch((err) => setError(getErrorMessage(err)));
  useEffect(() => {
    api.get("/admin/wards").then((response) => setWards(response.data));
  }, []);
  useEffect(() => {
    load();
  }, [page]);
  function search(event) {
    event.preventDefault();
    setPage(1);
    load(1);
  }
  async function exportCsv() {
    try {
      const response = await api.get("/admin/export/csv", {
        params: filters,
        responseType: "blob",
      });
      const url = URL.createObjectURL(response.data);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = "evaluations.csv";
      anchor.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  }
  return (
    <>
      <PageHeader
        eyebrow="FEEDBACK"
        title="ผลการประเมิน"
        description="ค้นหา ตรวจสอบคะแนน และดูรายละเอียดความคิดเห็น"
      >
        <button className="btn btn-outline-primary" onClick={exportCsv}>
          <FileDown size={16} className="me-2" />
          ส่งออก CSV
        </button>
      </PageHeader>
      <Alert error={error} />
      <form className="filter-bar" onSubmit={search}>
        <div className="search-field">
          <Search size={17} />
          <input
            placeholder="ค้นหาอาคาร Ward หรือเตียง"
            value={filters.q}
            onChange={(event) =>
              setFilters({ ...filters, q: event.target.value })
            }
          />
        </div>
        <select
          className="form-select"
          value={filters.ward_id}
          onChange={(event) =>
            setFilters({ ...filters, ward_id: event.target.value })
          }
        >
          <option value="">ทุก Ward</option>
          {wards.map((ward) => (
            <option key={ward.ward_id} value={ward.ward_id}>
              {ward.ward_name}
            </option>
          ))}
        </select>
        <select
          className="form-select"
          aria-label="กรองตามสถานะปัญหา"
          value={filters.has_problem}
          onChange={(event) =>
            setFilters({ ...filters, has_problem: event.target.value })
          }
        >
          <option value="">มีและไม่มีปัญหา</option>
          <option value="1">มีปัญหา</option>
          <option value="0">ไม่มีปัญหา</option>
        </select>
        <input
          className="form-control"
          type="date"
          aria-label="ตั้งแต่วันที่"
          value={filters.from}
          onChange={(event) =>
            setFilters({ ...filters, from: event.target.value })
          }
        />
        <input
          className="form-control"
          type="date"
          aria-label="ถึงวันที่"
          value={filters.to}
          onChange={(event) =>
            setFilters({ ...filters, to: event.target.value })
          }
        />
        <button className="btn btn-primary">ค้นหา</button>
      </form>
      <section className="content-card">
        <div className="table-responsive">
          <table className="table data-table align-middle">
            <thead>
              <tr>
                <th>เตียง</th>
                <th>ผู้ประเมิน</th>
                <th>คะแนน</th>
                <th>แจ้งปัญหา</th>
                <th>วันที่</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {data.data.map((item) => (
                <tr key={item.evaluation_id}>
                  <td>
                    <b>
                      {item.building_name}
                      {item.ward_name && item.ward_name !== item.building_name
                        ? ` · ${item.ward_name}`
                        : ""}{" "}
                      · {item.bed_name || "ไม่ระบุเตียง"}
                    </b>
                    <small>#{item.evaluation_id}</small>
                  </td>
                  <td>
                    {respondentLabels[item.respondent_type] ||
                      item.respondent_type}
                  </td>
                  <td>
                    <span className="score-pill">
                      <Star size={13} fill="currentColor" />
                      {Number(item.overall_score).toFixed(2)}
                    </span>
                  </td>
                  <td>
                    <span
                      className={`status ${item.has_problem ? "status-warning" : "status-ok"}`}
                    >
                      {item.has_problem ? "มีปัญหา" : "ไม่มี"}
                    </span>
                  </td>
                  <td>
                    {new Date(item.created_at).toLocaleDateString("th-TH")}
                  </td>
                  <td>
                    <Link
                      className="table-link"
                      to={`/admin/evaluations/${item.evaluation_id}`}
                    >
                      ดูรายละเอียด →
                    </Link>
                  </td>
                </tr>
              ))}
              {!data.data.length && (
                <tr>
                  <td colSpan="6">
                    <div className="empty-state">ไม่พบข้อมูลการประเมิน</div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <Pagination
          page={page}
          pages={Math.max(
            1,
            Math.ceil(
              (data.pagination.total || 0) / (data.pagination.limit || 20),
            ),
          )}
          onChange={setPage}
        />
      </section>
    </>
  );
}
function Pagination({ page, pages, onChange }) {
  return (
    pages > 1 && (
      <div className="pagination-row">
        <span>
          หน้า {page} จาก {pages}
        </span>
        <div>
          <button disabled={page <= 1} onClick={() => onChange(page - 1)}>
            ก่อนหน้า
          </button>
          <button disabled={page >= pages} onClick={() => onChange(page + 1)}>
            ถัดไป
          </button>
        </div>
      </div>
    )
  );
}

function EvaluationDetail() {
  const { id } = useParams();
  const [item, setItem] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    api
      .get(`/admin/evaluations/${id}`)
      .then((response) => setItem(response.data))
      .catch((err) => setError(getErrorMessage(err)));
  }, [id]);
  return (
    <>
      <PageHeader
        eyebrow="EVALUATION DETAIL"
        title="รายละเอียดผลประเมิน"
        description={`แบบประเมิน #${id}`}
      >
        <Link className="btn btn-outline-secondary" to="/admin/evaluations">
          กลับรายการ
        </Link>
      </PageHeader>
      <Alert error={error} />
      {item && (
        <div className="detail-grid">
          <section className="content-card detail-card">
            <h2>ข้อมูลการประเมิน</h2>
            <dl className="detail-list">
              <dt>อาคาร / Ward / เตียง</dt>
              <dd>
                {item.building_name}
                {item.ward_name && item.ward_name !== item.building_name
                  ? ` · ${item.ward_name}`
                  : ""}{" "}
                · {item.bed_name || "ไม่ระบุเตียง"}
              </dd>
              <dt>ผู้ประเมิน</dt>
              <dd>
                {respondentLabels[item.respondent_type] || item.respondent_type}
              </dd>
              <dt>คะแนนเฉลี่ย</dt>
              <dd>
                <span className="score-pill">
                  <Star size={13} fill="currentColor" />
                  {Number(item.overall_score).toFixed(2)} / 5
                </span>
              </dd>
              <dt>วันที่</dt>
              <dd>{new Date(item.created_at).toLocaleString("th-TH")}</dd>
              <dt>ข้อเสนอแนะ</dt>
              <dd>{item.suggestion || "—"}</dd>
            </dl>
          </section>
          <section className="content-card detail-card">
            <h2>คะแนนรายหัวข้อ</h2>
            {item.scores.map((score) => (
              <div className="score-detail" key={score.topic_code}>
                <span>{topicLabels[score.topic_code] || score.topic_code}</span>
                <b>
                  <Star size={14} fill="currentColor" /> {score.score} / 5
                </b>
              </div>
            ))}
          </section>
          <section className="content-card detail-card full-width">
            <h2>รายการแจ้งปัญหา</h2>
            {item.problem_reports.length ? (
              item.problem_reports.map((report) => (
                <div className="report-detail" key={report.report_id}>
                  <div className="report-meta">
                    {report.categories || "ไม่ระบุหมวดหมู่"} ·{" "}
                    {new Date(report.created_at).toLocaleString("th-TH")}
                  </div>
                  <p>{report.description || "ไม่ได้ระบุรายละเอียด"}</p>
                  <div className="image-list">
                    {report.images.map((image) => (
                      <a
                        key={image.image_id}
                        href={problemImageUrl(image.image_id)}
                        target="_blank"
                        rel="noreferrer"
                      >
                        <img
                          src={problemImageUrl(image.image_id)}
                          alt={image.original_filename}
                        />
                      </a>
                    ))}
                  </div>
                </div>
              ))
            ) : (
              <div className="empty-state">ไม่มีรายการแจ้งปัญหา</div>
            )}
          </section>
        </div>
      )}
    </>
  );
}

function Reports() {
  const [reports, setReports] = useState([]);
  const [query, setQuery] = useState("");
  const [error, setError] = useState("");
  const load = () =>
    api
      .get("/admin/problem-reports", { params: { q: query } })
      .then((response) => setReports(response.data))
      .catch((err) => setError(getErrorMessage(err)));
  useEffect(() => {
    load();
  }, []);
  return (
    <>
      <PageHeader
        eyebrow="ISSUE REPORTS"
        title="รายการแจ้งปัญหา"
        description="ติดตามปัญหาและสิ่งที่ต้องปรับปรุงจากผู้ใช้บริการ"
      />
      <Alert error={error} />
      <form
        className="filter-bar compact-filter"
        onSubmit={(event) => {
          event.preventDefault();
          load();
        }}
      >
        <div className="search-field">
          <Search size={17} />
          <input
            placeholder="ค้นหาปัญหา อาคาร หรือเตียง"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
        </div>
        <button className="btn btn-primary">ค้นหา</button>
      </form>
      <section className="content-card">
        <div className="table-responsive">
          <table className="table data-table align-middle">
            <thead>
              <tr>
                <th>เตียง</th>
                <th>รายละเอียด</th>
                <th>หมวดหมู่</th>
                <th>รูปภาพ</th>
                <th>วันที่</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {reports.map((report) => (
                <tr key={report.report_id}>
                  <td>
                    <b>
                      {report.building_name}
                      {report.ward_name &&
                      report.ward_name !== report.building_name
                        ? ` · ${report.ward_name}`
                        : ""}{" "}
                      · {report.bed_name || "ไม่ระบุเตียง"}
                    </b>
                    <small>รายงาน #{report.report_id}</small>
                  </td>
                  <td className="description-cell">
                    {report.description || "ไม่ระบุรายละเอียด"}
                  </td>
                  <td>{report.categories || "—"}</td>
                  <td>{report.image_count}</td>
                  <td>
                    {new Date(report.created_at).toLocaleDateString("th-TH")}
                  </td>
                  <td>
                    <Link
                      className="table-link"
                      to={`/admin/reports/${report.report_id}`}
                    >
                      ดูรายละเอียด →
                    </Link>
                  </td>
                </tr>
              ))}
              {!reports.length && (
                <tr>
                  <td colSpan="6">
                    <div className="empty-state">ไม่พบรายการแจ้งปัญหา</div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
function ReportDetail() {
  const { id } = useParams();
  const [report, setReport] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    api
      .get(`/admin/problem-reports/${id}`)
      .then((response) => setReport(response.data))
      .catch((err) => setError(getErrorMessage(err)));
  }, [id]);
  return (
    <>
      <PageHeader
        eyebrow="REPORT DETAIL"
        title="รายละเอียดการแจ้งปัญหา"
        description={`รายการ #${id}`}
      >
        <Link className="btn btn-outline-secondary" to="/admin/reports">
          กลับรายการ
        </Link>
      </PageHeader>
      <Alert error={error} />
      {report && (
        <section className="content-card detail-card">
          <h2>
            {report.building_name}
            {report.ward_name && report.ward_name !== report.building_name
              ? ` · ${report.ward_name}`
              : ""}{" "}
            · {report.bed_name || "ไม่ระบุเตียง"}
          </h2>
          <p className="report-meta">
            {report.categories || "ไม่ระบุหมวดหมู่"} ·{" "}
            {new Date(report.created_at).toLocaleString("th-TH")}
          </p>
          <p>{report.description || "ไม่ได้ระบุรายละเอียด"}</p>
          <div className="image-list">
            {report.images.map((image) => (
              <a
                key={image.image_id}
                href={problemImageUrl(image.image_id)}
                target="_blank"
                rel="noreferrer"
              >
                <img
                  src={problemImageUrl(image.image_id)}
                  alt={image.original_filename}
                />
              </a>
            ))}
          </div>
          <Link to={`/admin/evaluations/${report.evaluation_id}`}>
            ดูแบบประเมินที่เกี่ยวข้อง →
          </Link>
        </section>
      )}
    </>
  );
}

function AdminPage({ children }) {
  return (
    <AdminLayout>
      <div className="admin-content">{children}</div>
    </AdminLayout>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<EvaluationForm />} />
      <Route path="/admin/login" element={<Login />} />
      <Route
        path="/admin"
        element={
          <AdminPage>
            <Dashboard />
          </AdminPage>
        }
      />
      <Route
        path="/admin/qr-codes"
        element={
          <AdminPage>
            <QrManagement />
          </AdminPage>
        }
      />
      <Route
        path="/admin/evaluations"
        element={
          <AdminPage>
            <Evaluations />
          </AdminPage>
        }
      />
      <Route
        path="/admin/evaluations/:id"
        element={
          <AdminPage>
            <EvaluationDetail />
          </AdminPage>
        }
      />
      <Route
        path="/admin/reports"
        element={
          <AdminPage>
            <Reports />
          </AdminPage>
        }
      />
      <Route
        path="/admin/reports/:id"
        element={
          <AdminPage>
            <ReportDetail />
          </AdminPage>
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
